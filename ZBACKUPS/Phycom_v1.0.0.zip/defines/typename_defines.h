#define text string
