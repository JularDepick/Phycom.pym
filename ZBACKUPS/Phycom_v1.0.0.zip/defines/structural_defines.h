#define ruif if
#define elif else if
#define ruse else

#define NUSTR ""