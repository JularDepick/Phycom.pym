/* Phycom.pym
 * Copyright: 1724834368@qq.com
 */

#include <bits/stdc++.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;

string comzzzz_about() {
	string respond = "������ַ��https://JularDepick.github.io/\n";
	system("start https://JularDepick.github.io/");

	return respond;
}