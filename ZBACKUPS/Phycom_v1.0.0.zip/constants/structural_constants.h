/* Phycom.pym
 * Copyright: 1724834368@qq.com
 */

#include <bits/stdc++.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;

HWND Winptr = GetActiveWindow();
const string Phycom_head = "Phycom/.pym> ";
const string User_head =   "Phycom/User> ";
const string Exit_str =   "Exit!";