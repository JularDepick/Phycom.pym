/* Phycom.pym
 * Copyright: 1724834368@qq.com
 */

#include <bits/stdc++.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

using namespace std;

struct WIDECHAR {
	int firbyte = 0;
	int secbyte = 0;
};

vector<pair<string,WIDECHAR>> AVARS_WIDECHAR= {};
