#include <bits/stdc++.h>
using namespace std;

bool check_value(string vartype, string varvalue) {
	if (vartype == "int") {
		regex intreg("(([0])|([-]?[1-9]+[0-9]*))");
		return (regex_match(varvalue, intreg));
	}
	if (vartype == "bool") {
		return (varvalue == "yes" || varvalue == "no" || varvalue == "true" || varvalue == "false" || varvalue == "1" || varvalue == "0");
	}
	if (vartype == "float") {
		regex floatreg("((([0])|([-]?[1-9]+[0-9]*))|([-]?[0][.][1-9]+)|([0][.][0-9]+)|([-]?[1-9]+[0-9]*[.][0-9]+))");
		return (regex_match(varvalue, floatreg));
	}
	if (vartype == "char") {
		return (varvalue.size() == 1 || (varvalue.size() == 2 && (varvalue[0] >= 128 || varvalue[0] < 0)));
	}
	if (vartype == "text") {
		return 1;
	}
	return 0;
}


int main() {
	/*
		string a, b;
		while (1) {
			cin >> a >> b;
			cout << check_value(a, b) << endl << endl;
		}*/
	string s;
	cin >> s;
	cout << s << endl;
}